-- name: Server Settings v1.0.2
-- description: Allows you to change the server settings in game, \\#ff6904\\by Piko Piko/Amy Rose, Tee-hee
sSeeServerSettings = 0
-----------------
--server events--
-----------------
playerInteractionsText = ''
onStarGetText = ''
playerInteractions = {
    [0] = function() playerInteractionsText = 'NONE'   end,
    [1] = function() playerInteractionsText = 'SOLID'  end,
    [2] = function() playerInteractionsText = 'DAMAGE' end
}

onStarGet = {
    [0] = function() onStarGetText = 'EXIT'    end,
    [1] = function() onStarGetText = 'NO EXIT' end,
    [2] = function() onStarGetText = 'NONSTOP' end
}

gGlobalSyncTable.bubbleDeath = gServerSettings.bubbleDeath
gGlobalSyncTable.enableCheats = gServerSettings.enableCheats
gGlobalSyncTable.playerInteractions = gServerSettings.playerInteractions
gGlobalSyncTable.playerKnockbackStrength = gServerSettings.playerKnockbackStrength
gGlobalSyncTable.shareLives = gServerSettings.shareLives
gGlobalSyncTable.skipIntro = gServerSettings.skipIntro
gGlobalSyncTable.stayInLevelAfterStar = gServerSettings.stayInLevelAfterStar

function update()
    gServerSettings.bubbleDeath = gGlobalSyncTable.bubbleDeath
    -- gServerSettings.enableCheats = gGlobalSyncTable.enableCheats
    gServerSettings.playerInteractions = gGlobalSyncTable.playerInteractions
    gServerSettings.playerKnockbackStrength = gGlobalSyncTable.playerKnockbackStrength
    gServerSettings.shareLives = gGlobalSyncTable.shareLives
    gServerSettings.skipIntro = gGlobalSyncTable.skipIntro
    gServerSettings.stayInLevelAfterStar = gGlobalSyncTable.stayInLevelAfterStar
    sSeeServerSettings = sSeeServerSettings - 1
end

function on_bubble_command(msg)
    if msg == 'on' then
        djui_chat_message_create('Bubble Death is now on')
        gGlobalSyncTable.bubbleDeath = 1
        return true
    elseif msg == 'off' then
        djui_chat_message_create('Bubble Death is now off')
        gGlobalSyncTable.bubbleDeath = 0
        return true
    end
    return false
end

function on_pla_int_command(msg)
    if msg == 'solid' then
        djui_chat_message_create('Player Interactions are on')
        gGlobalSyncTable.playerInteractions = 1
        return true
    elseif msg == 'friendly-fire' then
        djui_chat_message_create('Friendly Fire is enabled')
        gGlobalSyncTable.playerInteractions = 2
        return true
    end
    return false
end

function on_pla_kb_int_command(msg)
    gGlobalSyncTable.playerKnockbackStrength = tonumber(msg)
    djui_chat_message_create("Player Knockback Strength is now " .. gGlobalSyncTable.playerKnockbackStrength)
    return true
end

function on_share_lives_command(msg)
    if msg == 'on' then
        djui_chat_message_create("Share lives is now on")
        gGlobalSyncTable.shareLives = 1
        return true
    elseif msg == 'off' then
        djui_chat_message_create("Share lives is now off")
        gGlobalSyncTable.shareLives = 0
        return true
    end
    return false
end

function on_star_get_command(msg)
    if msg == 'leave' then
        djui_chat_message_create("You'll leave the level on star get")
        gGlobalSyncTable.stayInLevelAfterStar = 0
        return true
    elseif msg == 'stay-in' then
        djui_chat_message_create("You'll now stay in level after star")
        gGlobalSyncTable.stayInLevelAfterStar = 1
        return true
    elseif msg == 'nonstop' then
        djui_chat_message_create("Nonstop mode is on")
        gGlobalSyncTable.stayInLevelAfterStar = 2
        return true
    end
    return false
end

--Disable Cannons--

gGlobalSyncTable.doCannon = true

function allow_interact(m, obj, intee)
    if intee == INTERACT_CANNON_BASE and not gGlobalSyncTable.doCannon then
        m.pos.y = m.pos.y + 500
        m.pos.x = m.pos.x - 200
        m.forwardVel = 0
        return false
    else
        return true
    end
end

function on_cannon_command(msg)
    if not network_is_server() or network_is_moderator() then
        djui_chat_message_create("Only a server Host/Moderator can change this")

        return true
    end

    if msg == "on" then
        djui_chat_message_create("Cannons are now enabled")

        gGlobalSyncTable.doCannon = true

        return true
    elseif msg == "off" then
        djui_chat_message_create("Cannons are now disabled")

        gGlobalSyncTable.doCannon = false

        return true
    else
        djui_chat_message_create("Please enter a valid option [on|off]")

        return true
    end
end

hook_event(HOOK_UPDATE, update)
if network_is_server() or network_is_moderator() then
    hook_chat_command("bubble", "- [on|off] allows you to change the bubble on death server setting", on_bubble_command)
    hook_chat_command("interactions", "- [non-solid|solid|friendly-fire] allows you to change player interactions", on_pla_int_command)
    hook_chat_command("knockback", "- [integer] change how far you send people flying!", on_pla_kb_int_command)
    hook_chat_command("share-lives", "- [on|off] change if live sharing is on or off", on_share_lives_command)
    hook_chat_command("on-star-get", "- [leave|stay-in|nonstop] change what happens on star get", on_star_get_command)
    hook_chat_command("cannon", "[on|off] allow players to go in cannons or not", on_cannon_command)
end